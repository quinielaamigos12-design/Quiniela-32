
// ===============================
// QUINIELA32 FULL LOGIC
// ===============================

// ---- CONSTANTES ----
const ADMIN_USER = "admin";
const ADMIN_PASS = "1234";

const CIERRE_DIA = 4;      // jueves
const CIERRE_HORA = 16;    // 16:00

// ---- UTILIDADES ----
function load(key, def){ 
    return JSON.parse(localStorage.getItem(key) || JSON.stringify(def)); 
}
function save(key, val){ 
    localStorage.setItem(key, JSON.stringify(val)); 
}

// ---- BASE DE DATOS ----
let jugadores = load("jugadores", []); 
let pronosticos = load("pronosticos", {}); 
let jornadas = load("jornadas", []);

// ---- LOGIN ----
function login(nombre, pass){
    if(nombre === ADMIN_USER && pass === ADMIN_PASS){
        window.location = "admin.html";
        return true;
    }

    let j = jugadores.find(x=>x.nombre === nombre);
    if(!j) return false;

    if(!j.pass){
        j.pass = pass;
        save("jugadores", jugadores);
        alert("Contraseña creada.");
        window.location = "jugador.html?user="+nombre;
        return true;
    }

    if(j.pass === pass){
        window.location = "jugador.html?user="+nombre;
        return true;
    }

    return false;
}

// ---- ADMIN: CREAR JUGADORES ----
function adminCrearJugador(nombre){
    if(jugadores.find(x=>x.nombre === nombre)){
        alert("Jugador ya existe");
        return;
    }
    jugadores.push({nombre, pass:null});
    save("jugadores", jugadores);
    alert("Jugador creado");
}

// ---- JORNADAS AUTOMÁTICAS (LALIGA SIMPLIFICADA) ----
function generarJornada(){
    let jornadaNum = jornadas.length + 1;
    let partidos = [
        "Real Madrid - Barcelona",
        "Atlético - Sevilla",
        "Valencia - Betis",
        "Villarreal - Athletic",
        "Real Sociedad - Girona",
        "Osasuna - Getafe",
        "Rayo - Mallorca"
    ];

    jornadas.push({ id:jornadaNum, partidos, resultados:[]});
    save("jornadas", jornadas);
    alert("Jornada "+jornadaNum+" creada");
}

// ---- PRONÓSTICOS ----
function guardarPronostico(user, jornadaId, lista){
    if(!pronosticos[user]) pronosticos[user] = {};
    pronosticos[user][jornadaId] = lista;
    save("pronosticos", pronosticos);
    alert("Pronóstico guardado.");
}

// ---- CIERRE AUTOMÁTICO ----
function cierreAutomatico(){
    let ahora = new Date();
    if(ahora.getDay() === CIERRE_DIA && ahora.getHours() >= CIERRE_HORA){
        jugadores.forEach(j => {
            jornadas.forEach(jor => {
                if(!pronosticos[j.nombre] || !pronosticos[j.nombre][jor.id]){
                    let auto = jor.partidos.map(()=> "X"); // automático = X
                    guardarPronostico(j.nombre, jor.id, auto);
                }
            });
        });
    }
}

// ---- CÁLCULO DE ACIERTOS ----
function calcularAciertos(jornada){
    let tabla = [];
    jugadores.forEach(j => {
        let p = pronosticos[j.nombre]?.[jornada.id] || [];
        let aciertos = 0;
        for(let i=0;i<p.length;i++){
            if(p[i] === jornada.resultados[i]) aciertos++;
        }
        tabla.push({ jugador:j.nombre, aciertos });
    });
    return tabla;
}

// ---- MULTAS ----
function calcularMultas(tabla){
    tabla.sort((a,b)=>a.aciertos - b.aciertos);
    if(tabla.length < 2) return [];
    tabla[0].multa = 2;
    tabla[1].multa = 1;
    return tabla;
}

cierreAutomatico();
